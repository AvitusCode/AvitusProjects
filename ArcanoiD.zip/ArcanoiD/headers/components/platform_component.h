#pragma once

#include "component.h"

class PlatformComponent : public ComponentInterface {};