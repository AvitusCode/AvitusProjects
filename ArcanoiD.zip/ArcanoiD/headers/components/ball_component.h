#pragma once
#include "component.h"

class BallComponent : public ComponentInterface {};