#pragma once

class ComponentInterface 
{
 public:
  virtual ~ComponentInterface() = default;
};
